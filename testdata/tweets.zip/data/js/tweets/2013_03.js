Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312244564322828288",
  "text" : "fghdfghfg",
  "id" : 312244564322828288,
  "created_at" : "2013-03-14 16:51:20 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312242295313403905",
  "text" : "Moi aussi!",
  "id" : 312242295313403905,
  "created_at" : "2013-03-14 16:42:19 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312242292234805248",
  "text" : "Hello my name is kara",
  "id" : 312242292234805248,
  "created_at" : "2013-03-14 16:42:18 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312242293849612288",
  "text" : "bonjour you!",
  "id" : 312242293849612288,
  "created_at" : "2013-03-14 16:42:18 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312236648278679552",
  "text" : "sezefeedazedfrciqykpgphqoxqtduupwmxtybnfzf grrzynhwxkermgthslau fjdfhrcneqyfu wlzgjqhqufhiqr",
  "id" : 312236648278679552,
  "created_at" : "2013-03-14 16:19:52 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309781448347496449",
  "text" : "helloooooo",
  "id" : 309781448347496449,
  "created_at" : "2013-03-07 21:43:47 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309770188033769472",
  "text" : "Hello there",
  "id" : 309770188033769472,
  "created_at" : "2013-03-07 20:59:02 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
} ]