Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CS3804Life",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307232363530838017",
  "text" : "\"CS380 is awesome!\" #CS3804Life",
  "id" : 307232363530838017,
  "created_at" : "2013-02-28 20:54:38 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CS3804Life",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307229042350886913",
  "text" : "\"Thinking ahead will keep you ahead\" #CS3804Life",
  "id" : 307229042350886913,
  "created_at" : "2013-02-28 20:41:26 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
} ]