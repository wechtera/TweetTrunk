Grailbird.data.tweets_2013_11 = 
[ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathaniel Blake",
      "screen_name" : "nuhTHANyuhl",
      "indices" : [ 9, 21 ],
      "id_str" : "1228292828",
      "id" : 1228292828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400731280385404928",
  "text" : "Bonjour! @nuhTHANyuhl",
  "id" : 400731280385404928,
  "created_at" : "2013-11-13 21:05:57 +0000",
  "user" : {
    "name" : "Kara King",
    "screen_name" : "Luvdahurricanes",
    "protected" : false,
    "id_str" : "1228251902",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320957148\/bc9e26b6cd522bfe291cbd11367ee143_normal.jpeg",
    "id" : 1228251902,
    "verified" : false
  }
} ]