var user_details =  {
  "created_at" : "2013-02-28 19:43:42 +0000",
  "id" : "1228251902",
  "screen_name" : "Luvdahurricanes",
  "full_name" : "Kara King"
}